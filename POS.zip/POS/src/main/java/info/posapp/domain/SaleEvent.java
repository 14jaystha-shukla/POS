package info.posapp.domain;

public class SaleEvent {
    private Double salePrice;
    private Double payment;
    private Double change;

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getPayment() {
        return payment;
    }

    public void setPayment(Double payment) {
        this.payment = payment;
    }

    public Double getChange() {
        return change;
    }

    public void setChange(Double change) {
        this.change = change;
    }

    @Override
    public String toString() {
        return "SaleEvent{" +
                "salePrice=" + salePrice +
                ", payment=" + payment +
                ", change=" + change +
                '}';
    }

}
