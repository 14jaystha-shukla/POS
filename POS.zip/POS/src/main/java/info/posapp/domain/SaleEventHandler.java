package info.posapp.domain;

import java.text.DecimalFormat;
import java.util.concurrent.ThreadLocalRandom;

public class SaleEventHandler {

    DecimalFormat df= new DecimalFormat("#.##");

    public Double generateSalePrice() {
        Double salePrice = ThreadLocalRandom.current().nextDouble(1.00, 100.01);
        //System.out.println("Random sale Price before rounding is : " + salePrice);
        System.out.println("Random sale price  is : " + Double.valueOf(df.format(salePrice)));
        return Double.valueOf(df.format(salePrice));
    }

    public Double generatePayment(Double salePrice) {
        Double payment = ThreadLocalRandom.current().nextDouble(salePrice, 200.01);
        //System.out.println("Random payment before rounding is : " + payment);
        System.out.println("Random payment is : " + Double.valueOf(df.format(payment)));
        return Double.valueOf(df.format(payment));
    }

    public Double calculateChange(Double payment, Double salePrice) {
        Double change =  payment - salePrice;
        //System.out.println("Change returned before rounding is : " + change);
        System.out.println("Change returned is : " + Double.valueOf(df.format(change)));
        System.out.println("=========================================================");
        System.out.println("Return change to customer : "+"\n"+ countChange(Double.valueOf(df.format(change))));
        return Double.valueOf(df.format(change));
    }

    private String countChange(Double change) {
        String result = "";
        final int[] denominations =
                { 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1 };
        int[] count = new int[denominations.length];
        Double ChangeToCents= change * 100;

        // Loop through each denomination (starting at largest)
        for (int i=0; i<denominations.length; i++) {
            while (ChangeToCents>=denominations[i]) {
                count[i]++;
                ChangeToCents -= denominations[i];
            }
        }

        // Output the result
        for (int i=0; i<denominations.length; i++) {
            if (count[i]>0) {
                if(denominations[i] > 500 ) {
                    result += count[i] + " x R" + denominations[i] / 100 + " Note" +"\n";
                }else if(denominations[i] >= 100) {
                    result += count[i] + " x R" + denominations[i]/100 + " Coin"+"\n";
                    }else{
                    result += count[i] + " x " + denominations[i] + "c Coin"+"\n";
                    }
                }
            }
         return result;
    }
}

