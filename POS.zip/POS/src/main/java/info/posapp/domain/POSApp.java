package info.posapp.domain;

public class POSApp {

    public static void main(String[] args) {
        SaleEvent saleEvent=new SaleEvent();
        POSDao posDao=new POSDao();
        SaleEventHandler handler=new SaleEventHandler();
        saleEvent.setSalePrice(handler.generateSalePrice());
        saleEvent.setPayment(handler.generatePayment(saleEvent.getSalePrice()));
        saleEvent.setChange(handler.calculateChange(saleEvent.getPayment(), saleEvent.getSalePrice()));
        System.out.println(saleEvent.toString());
        posDao.save(saleEvent);
    }
}
