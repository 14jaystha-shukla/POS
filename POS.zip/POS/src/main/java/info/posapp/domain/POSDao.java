package info.posapp.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class POSDao {

    public void save(SaleEvent saleEvent) {
        try
        {
            // create a mysql database connection
            String myDriver = "com.mysql.jdbc.Driver";
            String myUrl = "jdbc:mysql://localhost:3306/pos";
            Class.forName(myDriver);
            Connection conn = DriverManager.getConnection(myUrl, "root", "root");

            Statement st = conn.createStatement();

            // note that i'm leaving "date_created" out of this insert statement
            String sql = "INSERT INTO sale_event (saleprice, payment, change_return, insert_date) "
                    +"VALUES (?,?,?,NOW())" ;

            PreparedStatement pstmt = conn.prepareStatement(sql,
                    Statement.RETURN_GENERATED_KEYS);

            pstmt.setDouble(1, saleEvent.getSalePrice());
            pstmt.setDouble(2, saleEvent.getPayment());
            pstmt.setDouble(3, saleEvent.getChange());
            int rowAffected = pstmt.executeUpdate();
            System.out.println(rowAffected+" Row Inserted");
            conn.close();
        }
        catch (Exception e)
        {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }

    }
}
