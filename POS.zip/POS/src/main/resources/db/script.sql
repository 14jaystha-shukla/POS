use pos;

create table sale_event(
id int unsigned auto_increment not null,
saleprice double not null,
payment double not null,
change_return double not null,
insert_date datetime not null,
primary key (id)
);

select * from sale_event;